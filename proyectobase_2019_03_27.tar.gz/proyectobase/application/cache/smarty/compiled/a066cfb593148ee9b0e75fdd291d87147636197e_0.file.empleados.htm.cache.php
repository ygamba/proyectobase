<?php
/* Smarty version 3.1.30, created on 2019-03-27 21:15:04
  from "/var/www/proyectobase/application/modules/home/views/empleados.htm" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c9c2018a27b51_53084009',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a066cfb593148ee9b0e75fdd291d87147636197e' => 
    array (
      0 => '/var/www/proyectobase/application/modules/home/views/empleados.htm',
      1 => 1553724119,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:menusup.htm' => 1,
    'file:menuinf.htm' => 1,
  ),
),false)) {
function content_5c9c2018a27b51_53084009 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '3926860365c9c20189c67d3_96975317';
$_smarty_tpl->_subTemplateRender("file:menusup.htm", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php echo '<script'; ?>
>

    jQuery.noConflict();
    jQuery(document).on("ready", function () {


        var idioma_español = {
            "sProcessing": "Procesando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "No se encontraron resultados",
            "sEmptyTable": "Ningún dato disponible en esta tabla",
            "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast": "Último",
                "sNext": "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            }

        }


        jQuery('#dt_cliente tfoot th').each(function () {
            var title = jQuery(this).text();
            jQuery(this).html('<input type="text" id="' + title + '" placeholder="Buscar ' + title + '" />');
        });

        var columns = jQuery('#dt_cliente').find('thead').eq(0).find('th').length;


var table = jQuery('#dt_cliente').DataTable({
        dom: 'Bfrtip',
        language: idioma_español,
        buttons: [
            'copy', 'csv', 'excelHtml5'
            ,{
            	extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                className:'pdf'
            }
        ]
    } );


        jQuery('#dt_cliente tfoot tr').appendTo('#dt_cliente thead');


        jQuery('#Nombre').on('keyup', function () {
            table
                    .columns(0)
                    .search(this.value)
                    .draw();
        });

        jQuery('#Número_Doc').bind('keyup change', function () {
            table
                    .columns(1)
                    .search(this.value)
                    .draw();
        });

        jQuery('#Fecha_Nacimiento').on('keyup', function () {
            table
                    .columns(2)
                    .search(this.value)
                    .draw();
        });
	jQuery('#Direccion').on('keyup', function () {
            table
                    .columns(3)
                    .search(this.value)
                    .draw();
        });
        jQuery('#telefono').on('keyup', function () {
            table
                    .columns(4)
                    .search(this.value)
                    .draw();
        });
        jQuery('#Estado_Civil').on('keyup', function () {
            table
                    .columns(5)
                    .search(this.value)
                    .draw();
        });
        
        jQuery('#Numero_Hijos').on('keyup', function () {
            table
                    .columns(6)
                    .search(this.value)
                    .draw();
        });
        jQuery('#Nivel_Educativo').on('keyup', function () {
            table
                    .columns(7)
                    .search(this.value)
                    .draw();
        });
        jQuery('#Area_Compañia').on('keyup', function () {
            table
                    .columns(8)
                    .search(this.value)
                    .draw();
        });
        jQuery('#Sueldo').on('keyup', function () {
            table
                    .columns(9)
                    .search(this.value)
                    .draw();
        });
   

    });

<?php echo '</script'; ?>
>

<div class='col-md-12'>&nbsp;</div>
<div class='col-md-12'><h1>Listado Empleados</h1></div>



<div class="row">
    <div id="cuadro1" class="col-sm-12 col-md-12 col-lg-12">
        <div class="col-sm-offset-2 col-sm-8">
            <h3 class="text-center"> <small class="mensaje"></small></h3>
        </div>
        <div class="table-responsive col-sm-12">		
            <table id="dt_cliente" class="table dt-responsive" cellspacing="0" width="100%">
                <thead>
                    <tr>
                          <th>Nombre</th>                                            
			 <th>Número_Doc</th>                   	 
                         <th>Fecha_Nacimiento</th>
                         <th>Direccion</th>
                         <th>Teléfono</th>
                         <th>Estado_Civil</th>                         
                         <th>Numero_Hijos</th>
			 <th>Nivel_Educativo</th>
                         <th>Area_Compañia</th>
                         <th>Sueldo</th>          
                    </tr>
                </thead>					
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'empleado');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['empleado']->value) {
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->nombre;?>
 <?php echo $_smarty_tpl->tpl_vars['empleado']->value->apellidos;?>
</td>
			<td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->numdoc;?>
</td>                       
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->fechan;?>
</td>                                          
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->direccion;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->telefono;?>
</td>                           
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->estado;?>
</td>                    
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->numhij;?>
</td>                          
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->nivel;?>
</td> 
			<td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->area;?>
</td>                        
                        <td><?php echo $_smarty_tpl->tpl_vars['empleado']->value->sueldo;?>
</td>
                        
                    </tr>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
 
                </tbody>
                <tfoot>
                    <tr>
                         <th>Nombre</th>                                            
			 <th>Número_Doc</th>                   	 
                         <th>Fecha_Nacimiento</th>
                         <th>Direccion</th>
                         <th>Teléfono</th>
                         <th>Estado_Civil</th>                         
                         <th>Numero_Hijos</th>
			 <th>Nivel_Educativo</th>
                         <th>Area_Compañia</th>
                         <th>Sueldo</th>          
                    </tr>
                </tfoot>
            </table>
        </div>			
    </div>		
</div>

<div class='col-md-12'>&nbsp;</div>
<div class="row">
 <div class='col-md-12 text-center'>
            <a href="<?php echo base_url();?>
home" class="btn btn-danger">Regresar</a>             
        </div>    
 </div>
<div class='col-md-12'>&nbsp;</div> 

<?php $_smarty_tpl->_subTemplateRender("file:menuinf.htm", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        
<?php }
}
