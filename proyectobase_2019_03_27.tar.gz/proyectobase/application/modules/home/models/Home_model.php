<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model {

 
    function add() {  
   
        $data['nombre']= $this->input->post('nombre');
        $data['apellidos']= $this->input->post('apellidos');  
        $data['numdoc']= $this->input->post('numdoc');
        $data['fechan']= $this->input->post('fechan');        
        $data['direccion']= $this->input->post('direccion');
        $data['telefono']= $this->input->post('telefono');        
        $data['id_estadoci']= $this->input->post('estadoci');
        $data['numhij']= $this->input->post('numhij');
        $data['id_niveledu']= $this->input->post('niveledu');        
        $data['id_area']= $this->input->post('area');        
        $data['sueldo']= $this->input->post('sueldo');       
        
        $this->db->insert('empleados', $data);
        
        return $this->db->insert_id();
    }
    
    function get_empleados() {
        $this->db->select('empleados.*');   
        $this->db->select('areas.nombre as area');   
        $this->db->select('estadoc.estado as estado');
        $this->db->select('niveledu.nivel as nivel');     
        $this->db->from('empleados');         
        $this->db->join('areas', 'areas.id_area = empleados.id_area', 'left'); 
        $this->db->join('estadoc', 'estadoc.id_estadoci = empleados.id_estadoci', 'left'); 
        $this->db->join('niveledu', 'niveledu.id_niveledu = empleados.id_niveledu', 'left'); 
        $this->db->order_by('empleados.nombre','ASC');  
        $query = $this->db->get();                
       return $query->result(); 
    }
    
    function get_areas() {
        $this->db->select('id_area, nombre');   
        $this->db->from('areas');   
        $this->db->order_by('areas.nombre','ASC');  
        $query = $this->db->get();        
        return $query->result();
    }
    
   function get_estadoc() {
        $this->db->select('id_estadoci, estado');   
        $this->db->from('estadoc');   
        $this->db->order_by('estadoc.estado','ASC');  
        $query = $this->db->get();        
        return $query->result();
    }
    
    function get_niveledu() {
        $this->db->select('id_niveledu, nivel');   
        $this->db->from('niveledu');   
        $this->db->order_by('niveledu.nivel','ASC');  
        $query = $this->db->get();        
        return $query->result();
    }
    
}
