<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper(array('url', 'language','paginador'));       
        $this->load->model(array('Home_model'));   
        $this->load->library(array('session'));
    }
    
    public function index()
	{	
        
          if ($this->input->post()) {
             
              
               $id_insertco = $this->Home_model->add();
           
              if ($id_insertco) {                
                $this->session->set_flashdata('Su Inscripción fue realizada de forma satisfactoria');
                     redirect("home/index/");
               }else {                     
                     $this->session->set_flashdata('message', $this->upload->display_errors());
                         redirect("home/index/");
                 }
          }
        
        $areas = $this->Home_model->get_areas();
        $this->data['areas'] = array();
        $this->data['areas'][""] = "Selecciona Uno...";
        foreach ($areas as $area) {
            $this->data['areas'][$area->id_area] = $area->nombre;
        } 
      
        $estadocs = $this->Home_model->get_estadoc();
        $this->data['estadocs'] = array();
        $this->data['estadocs'][""] = "Selecciona Uno...";
        foreach ($estadocs as $estadoc) {
            $this->data['estadocs'][$estadoc->id_estadoci] = $estadoc->estado;
        } 
        
        $niveledu = $this->Home_model->get_niveledu();
        $this->data['niveledu'] = array();
        $this->data['niveledu'][""] = "Selecciona Uno...";
        foreach ($niveledu as $nivel) {
            $this->data['niveledu'][$nivel->id_niveledu] = $nivel->nivel;
        } 
        
        
        $this->data['action'] = base_url()."home/index/";
        $this->parser->parse("home.htm", $this->data);   
        
	}      
    function empleados() {
 
        $this->data['data'] = $this->Home_model->get_empleados();            
        $this->parser->parse("empleados.htm", $this->data); 
       
    }   
        
}
